# VerMagic Package

This is a simple ETL and plotting package. 